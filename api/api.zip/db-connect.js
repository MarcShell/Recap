import mysql from 'mysql';

export const db = mysql.createConnection({
	host: 'localhost',
	user: 'marc',
	password: '9655',
	database: 'recap',
});
